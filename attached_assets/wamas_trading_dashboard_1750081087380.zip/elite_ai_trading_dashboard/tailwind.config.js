module.exports = {
  content: ["./pages/*.{html,js}", "./index.html", "./js/*.js"],
  theme: {
    extend: {
      colors: {
        // Primary Colors
        primary: {
          50: "#E6F9FF", // electric-blue-50
          100: "#CCF3FF", // electric-blue-100
          200: "#99E7FF", // electric-blue-200
          300: "#66DBFF", // electric-blue-300
          400: "#33CFFF", // electric-blue-400
          500: "#00D4FF", // electric-blue-500
          600: "#00A3CC", // electric-blue-600
          700: "#007299", // electric-blue-700
          800: "#004166", // electric-blue-800
          900: "#001033", // electric-blue-900
          DEFAULT: "#00D4FF", // electric-blue
        },
        
        // Secondary Colors
        secondary: {
          50: "#F5F5F6", // charcoal-gray-50
          100: "#EBEBEC", // charcoal-gray-100
          200: "#D7D7D9", // charcoal-gray-200
          300: "#C3C3C6", // charcoal-gray-300
          400: "#AFAFB3", // charcoal-gray-400
          500: "#9B9BA0", // charcoal-gray-500
          600: "#7C7C82", // charcoal-gray-600
          700: "#5D5D64", // charcoal-gray-700
          800: "#3E3E46", // charcoal-gray-800
          900: "#1A1D23", // charcoal-gray-900
          DEFAULT: "#1A1D23", // charcoal-gray
        },

        // Accent Colors
        accent: {
          50: "#FFFBF0", // amber-50
          100: "#FFF7E0", // amber-100
          200: "#FFEFC2", // amber-200
          300: "#FFE7A3", // amber-300
          400: "#FFDF85", // amber-400
          500: "#FFD766", // amber-500
          600: "#FFB800", // amber-600
          700: "#CC9300", // amber-700
          800: "#996E00", // amber-800
          900: "#664900", // amber-900
          DEFAULT: "#FFB800", // amber
        },

        // Background Colors
        background: "#0F1114", // dark-background
        surface: {
          DEFAULT: "#1E2329", // elevated-surface
          light: "#2A2F36", // elevated-surface-light
        },

        // Text Colors
        text: {
          primary: "#FFFFFF", // white
          secondary: "#8C9196", // muted-gray
          tertiary: "#6B7280", // muted-gray-light
        },

        // Status Colors
        success: {
          50: "#E6FFF9", // professional-green-50
          100: "#CCFFF3", // professional-green-100
          200: "#99FFE7", // professional-green-200
          300: "#66FFDB", // professional-green-300
          400: "#33FFCF", // professional-green-400
          500: "#00FFC3", // professional-green-500
          600: "#00C896", // professional-green-600
          700: "#009669", // professional-green-700
          800: "#00643C", // professional-green-800
          900: "#00320F", // professional-green-900
          DEFAULT: "#00C896", // professional-green
        },

        warning: {
          50: "#FFFBF0", // amber-warning-50
          100: "#FFF7E0", // amber-warning-100
          200: "#FFEFC2", // amber-warning-200
          300: "#FFE7A3", // amber-warning-300
          400: "#FFDF85", // amber-warning-400
          500: "#FFD766", // amber-warning-500
          600: "#FFB800", // amber-warning-600
          700: "#CC9300", // amber-warning-700
          800: "#996E00", // amber-warning-800
          900: "#664900", // amber-warning-900
          DEFAULT: "#FFB800", // amber-warning
        },

        error: {
          50: "#FFF0F0", // critical-red-50
          100: "#FFE0E0", // critical-red-100
          200: "#FFC2C2", // critical-red-200
          300: "#FFA3A3", // critical-red-300
          400: "#FF8585", // critical-red-400
          500: "#FF6666", // critical-red-500
          600: "#FF4747", // critical-red-600
          700: "#CC3939", // critical-red-700
          800: "#992B2B", // critical-red-800
          900: "#661C1C", // critical-red-900
          DEFAULT: "#FF4747", // critical-red
        },

        // Border Colors
        border: {
          DEFAULT: "rgba(255, 255, 255, 0.1)", // subtle-border
          focus: "rgba(0, 212, 255, 0.3)", // focus-border
          hover: "rgba(255, 255, 255, 0.2)", // hover-border
        },
      },

      fontFamily: {
        sans: ['Inter', 'sans-serif'],
        inter: ['Inter', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
        data: ['JetBrains Mono', 'monospace'],
      },

      fontSize: {
        'xs': ['0.75rem', { lineHeight: '1rem' }],
        'sm': ['0.875rem', { lineHeight: '1.25rem' }],
        'base': ['1rem', { lineHeight: '1.5rem' }],
        'lg': ['1.125rem', { lineHeight: '1.75rem' }],
        'xl': ['1.25rem', { lineHeight: '1.75rem' }],
        '2xl': ['1.5rem', { lineHeight: '2rem' }],
        '3xl': ['1.875rem', { lineHeight: '2.25rem' }],
        '4xl': ['2.25rem', { lineHeight: '2.5rem' }],
        '5xl': ['3rem', { lineHeight: '1' }],
        '6xl': ['3.75rem', { lineHeight: '1' }],
      },

      boxShadow: {
        'minimal': '0 2px 8px rgba(0, 0, 0, 0.3)', // minimal-elevation
        'floating': '0 4px 16px rgba(0, 0, 0, 0.4)', // floating-elements
        'modal': '0 8px 32px rgba(0, 0, 0, 0.5)', // modal-overlay
        'glow-primary': '0 0 20px rgba(0, 212, 255, 0.3)',
        'glow-success': '0 0 20px rgba(0, 200, 150, 0.3)',
        'glow-warning': '0 0 20px rgba(255, 184, 0, 0.3)',
        'glow-error': '0 0 20px rgba(255, 71, 71, 0.3)',
      },

      backdropBlur: {
        xs: '2px',
        sm: '4px',
        md: '8px',
        lg: '16px',
        xl: '24px',
        '2xl': '32px',
      },

      animation: {
        'fade-in': 'fadeIn 300ms ease-out',
        'slide-up': 'slideUp 300ms ease-out',
        'pulse-subtle': 'pulse-subtle 2s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'glow': 'glow 2s ease-in-out infinite alternate',
      },

      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        slideUp: {
          '0%': { opacity: '0', transform: 'translateY(20px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'pulse-subtle': {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.7' },
        },
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(0, 212, 255, 0.2)' },
          '100%': { boxShadow: '0 0 20px rgba(0, 212, 255, 0.6)' },
        },
      },

      transitionDuration: {
        '200': '200ms',
        '300': '300ms',
        '500': '500ms',
      },

      transitionTimingFunction: {
        'ease-out': 'cubic-bezier(0, 0, 0.2, 1)',
      },

      spacing: {
        '18': '4.5rem',
        '88': '22rem',
        '128': '32rem',
      },

      borderRadius: {
        'xl': '0.75rem',
        '2xl': '1rem',
        '3xl': '1.5rem',
      },

      zIndex: {
        '60': '60',
        '70': '70',
        '80': '80',
        '90': '90',
        '100': '100',
      },
    },
  },
  plugins: [
    function({ addUtilities }) {
      const newUtilities = {
        '.glass': {
          'backdrop-filter': 'blur(16px)',
          'background': 'rgba(30, 35, 41, 0.8)',
          'border': '1px solid rgba(255, 255, 255, 0.1)',
        },
        '.glass-modal': {
          'backdrop-filter': 'blur(24px)',
          'background': 'rgba(15, 17, 20, 0.9)',
          'border': '1px solid rgba(255, 255, 255, 0.2)',
        },
        '.text-data': {
          'font-family': 'JetBrains Mono, monospace',
          'font-variant-numeric': 'tabular-nums',
        },
        '.hover-lift': {
          'transition': 'transform 200ms ease-out, box-shadow 200ms ease-out',
        },
        '.hover-lift:hover': {
          'transform': 'translateY(-2px)',
          'box-shadow': '0 4px 16px rgba(0, 0, 0, 0.4)',
        },
      }
      addUtilities(newUtilities)
    }
  ],
}