# نظام التداول بالذكاء الاصطناعي

## التشغيل السريع:
1. انسخ مفاتيح OKX إلى ملف .env
2. نفذ: `pip install -r local_requirements.txt`
3. نفذ: `python test_okx_connection.py`
4. نفذ: `./start_system.sh`

## الوصول:
- لوحة التحكم: http://localhost:3005
- التحليلات: http://localhost:5000

## للمساعدة:
اقرأ QUICK_START_ARABIC.md
